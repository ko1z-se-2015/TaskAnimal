package GenericTypes;

import Interfaces.Moveable;
import Interfaces.Walkable;

import java.util.ArrayList;

public class Cage<T extends Walkable> extends Habitat<T>{
    public Cage(int habitatSize) {
        super(habitatSize);
    }
}