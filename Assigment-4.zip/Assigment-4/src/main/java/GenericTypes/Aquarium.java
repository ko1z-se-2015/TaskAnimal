package GenericTypes;
import Interfaces.Moveable;
import Interfaces.Swimable;

import java.util.ArrayList;


public class Aquarium<T extends Swimable> extends Habitat<T> {
    public Aquarium(int habitatSize) {
        super(habitatSize);
    }
}

