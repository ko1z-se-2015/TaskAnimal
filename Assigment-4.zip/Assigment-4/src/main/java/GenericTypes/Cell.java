package GenericTypes;

import Interfaces.Flyable;
import Interfaces.Moveable;

import java.util.ArrayList;

public class Cell<T extends Flyable> extends Habitat<T>{
    public Cell(int habitatSize) {
        super(habitatSize);
    }
}
