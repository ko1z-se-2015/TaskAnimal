package Interfaces;

public interface Walkable extends Moveable {
}
