package Interfaces;

public interface Swimable extends Moveable {
}
