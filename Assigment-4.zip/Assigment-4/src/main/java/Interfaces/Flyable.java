package Interfaces;

public interface Flyable extends Moveable {
}
