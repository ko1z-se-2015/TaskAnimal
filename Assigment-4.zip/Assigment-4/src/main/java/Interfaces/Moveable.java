package Interfaces;

public interface Moveable {
    int getComfortableSpace();
}
