package AbstractClasses;

public abstract class Bird extends Animal {
}
