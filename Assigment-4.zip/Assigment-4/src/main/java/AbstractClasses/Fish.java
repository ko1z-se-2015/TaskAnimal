package AbstractClasses;

import Interfaces.Swimable;

public abstract class Fish extends Animal implements Swimable {
}
