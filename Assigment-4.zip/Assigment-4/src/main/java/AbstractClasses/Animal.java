package AbstractClasses;

import Interfaces.Moveable;

public abstract class Animal implements Moveable {

}
